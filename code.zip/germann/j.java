function generateWrongAnswersTable() {
    const table = document.createElement("table");
    table.innerHTML = "<tr><th>Your Answer</th><th>Correct Answer</th></tr>";

    wrongAnswers.forEach((entry) => {
        const row = table.insertRow();
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);

        cell1.textContent = entry.wrong;
        cell2.textContent = entry.correct;
    });

    document.getElementById("results").appendChild(table);



letterSquare.addEventListener("input", function () {
    const enteredText = letterSquare.textContent;
    // You can process the entered text here (e.g., to check if it matches the expected answer).
});

    
    function generateLetterSquares(wordLength) {
    const answerContainer = document.getElementById("answer-container");
    answerContainer.innerHTML = "";

    for (let i = 0; i < wordLength; i++) {
        const letterSquare = document.createElement("div");
        letterSquare.className = "letter-square";
        letterSquare.contentEditable = "true"; // Allow user to enter text
        letterSquare.addEventListener("input", function () {
            // Handle user input here (if needed)
        });
        answerContainer.appendChild(letterSquare);
    }
}

}
